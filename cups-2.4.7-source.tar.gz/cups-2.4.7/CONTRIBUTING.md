Contributing to CUPS
====================

CUPS is developed by OpenPrinting and distributed as open source software under
the Apache License, Version 2.0 with exceptions to allow linking to GPL2/LGPL2
code.

Contributions should be submitted either as pull requests or as attachments
(unified diffs) to bug reports on the OpenPrinting CUPS GitHub project at
<https://github.com/openprinting/cups>.
